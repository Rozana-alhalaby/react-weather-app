import React from "react";

function GridOfSquares({gridSize}){
    function generateSquares(size){
        let array =[];
        for(let i=1; i<= size*size; i++){
            array.push(i)
        }
        return array
    }
    return (
        <div>
            <span>
                Grid size is: {gridSize}
            </span>
            <div className="squares-container">
                {generateSquares(gridSize).map(function(arrElement){
                    return <p onClick={function(){console.log(arrElement)}} key={arrElement}>{arrElement}</p>
                })}
            </div>
        </div>
    )
}

export default GridOfSquares;