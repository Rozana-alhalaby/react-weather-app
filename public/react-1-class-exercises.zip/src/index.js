import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import GridOfSquares from "./components/GridOfSquares";

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <>
    <GridOfSquares gridSize={10}/>
  </>
);
