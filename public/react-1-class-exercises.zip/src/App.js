import { useState } from "react";
import './App.css';

function App() {
  const [counter, setCounter] = useState(0)
  function sub(){setCounter(counter-1)}
  function add(){setCounter(counter+1)}
  
  function isGreaterThan5(){
    if(counter>5){
      return true
    } else {
      return false
    }
  }
  
  return (
    <div className='App'>
      <div className='counter-app'>
        <div onClick={sub} className='sub'><span>-</span></div>
        <div className='output'>{counter}</div>
        <div onClick={add} className='add'><span>+</span></div>
      </div>
        {/* show only if counter greater than 5 */}
        {
          counter>5 && <p>Counter is greater than 5!</p>
        }
        {
          isGreaterThan5() && <p>Counter is greater than 5!</p>
        }
        {
          counter > 5 ? <p>Counter is greater than 5!</p> : <p>Counter is less than or equal to 5!</p>
        }
    </div>
  );
}

export default App;
